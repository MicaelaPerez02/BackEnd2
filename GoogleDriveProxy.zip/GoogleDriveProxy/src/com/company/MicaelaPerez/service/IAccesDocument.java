package com.company.MicaelaPerez.service;

public interface IAccesDocument {
    public String accessDocument(String url, String email);
}
