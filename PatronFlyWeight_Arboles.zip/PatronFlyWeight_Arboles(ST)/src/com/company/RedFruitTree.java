package com.company;

public class RedFruitTree extends FruitTree {

    public RedFruitTree() {
        super(500, 300, "red");
    }
}
