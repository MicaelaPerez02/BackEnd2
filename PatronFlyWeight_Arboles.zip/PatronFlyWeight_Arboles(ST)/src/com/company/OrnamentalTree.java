package com.company;

public class OrnamentalTree extends Tree {
    public OrnamentalTree() {
        super(200, 400, "green", "ornamental");

    }
}
