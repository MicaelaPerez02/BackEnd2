package com.company;

public class TurquoiseFruitTree extends FruitTree {

    public TurquoiseFruitTree() {
        super(100, 200, "turquoise");
    }
}
