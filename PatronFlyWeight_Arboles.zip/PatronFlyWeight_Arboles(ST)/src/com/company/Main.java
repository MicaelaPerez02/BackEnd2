package com.company;

public class Main {

    public static void main(String[] args) {
        Forest forest = new Forest();
        forest.plantTrees();
    }
}
