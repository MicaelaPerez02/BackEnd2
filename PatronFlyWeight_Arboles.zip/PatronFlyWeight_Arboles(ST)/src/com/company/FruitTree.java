package com.company;

public abstract class FruitTree extends Tree {

    public FruitTree(Integer height, Integer wide, String color) {
        super(height, wide, color,"fruit tree");
    }
}
