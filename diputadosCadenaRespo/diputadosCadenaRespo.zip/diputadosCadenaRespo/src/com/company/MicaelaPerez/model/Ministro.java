package com.company.MicaelaPerez.model;

import com.company.MicaelaPerez.service.Documento;

public class Ministro extends FuncionarioPublico {

    public Ministro() {
        this.acceso=2;
    }

}
