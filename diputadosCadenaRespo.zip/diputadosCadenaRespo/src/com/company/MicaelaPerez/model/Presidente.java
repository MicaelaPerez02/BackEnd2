package com.company.MicaelaPerez.model;

import com.company.MicaelaPerez.service.Documento;

public class Presidente extends FuncionarioPublico {

    public Presidente() {
        this.acceso=3;
    }
}
