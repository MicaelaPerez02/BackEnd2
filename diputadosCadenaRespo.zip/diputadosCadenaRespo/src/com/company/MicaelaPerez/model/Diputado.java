package com.company.MicaelaPerez.model;

import com.company.MicaelaPerez.service.Documento;

public class Diputado extends FuncionarioPublico {

    public Diputado() {
        this.acceso=1;
    }

}
