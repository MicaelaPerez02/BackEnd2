package com.dh.proxy.service;

public interface IConexionInternet {

    public void conectarCon(String url);
}
